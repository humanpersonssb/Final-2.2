using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Enemy : MonoBehaviour
{
    // controller
    public CharacterController2D controller;

    float horizontalmove = 0f;
    float horizontalmoveL = 0f;

    public float runspeed = 40f;
    [SerializeField] private int Enemynumber = 0;
    public int whichenemy = 1;
    public int letterenemy = 2;
    bool jump = false;
    bool crouch = false;
    bool jumpL = false;
    bool crouchL = false;

    // timers/score
    public bool countdown = false;
    public bool cantrigger = true;
    public int escore = 0;
    [SerializeField] GameObject txt;
    [SerializeField] GameObject count;
    [SerializeField] private float boomtimer = 5;

   // private PlayerInput playerInput;

    // Start is called before the first frame update
    void Start()
    {

    }

    private void Awake()
    {
       // playerInput = GetComponent<PlayerInput>();
        //playerInput.onActionTriggered += PlayerInput_onActionTriggered;
    }

    public void  PlayerInput_onActionTriggered(InputAction.CallbackContext context)
        {
        Debug.Log(context);
        }

    void FixedUpdate()
    {
        if (Enemynumber == whichenemy)
        {
            controller.Move(horizontalmove * Time.fixedDeltaTime, crouch, jump);
        }

        if (Enemynumber == letterenemy)
        {
            controller.Move(horizontalmoveL * Time.fixedDeltaTime, crouchL, jumpL);
        }
        jump = false;
        jumpL = false;
    }
    void emover()
    {
       horizontalmove = 0f;
    }
    void emovel()
    {
        horizontalmoveL = 0f;
    }
    public void OnTriggerEnter2D(Collider2D other)
    {
        //Debug.Log("player touched");

        if (other.gameObject.tag == "Player")
        {
            //Debug.Log("player touched");

            if (other.GetComponent<PlayerMove>().countd == true)
            {
                //cooldown
                if (cantrigger)
                {
                    cantrigger = false;
                    StartCoroutine(triggercd());
                    Debug.Log("enemy is it");
                    countdown = true;
                    other.GetComponent<PlayerMove>().countd = false;
                    other.GetComponent<PlayerMove>().countp.SetActive(false);
                    count.SetActive(true);
                    boomtimer = 5;
                    other.GetComponent<PlayerMove>().boomtimerp = 5;
                    StartCoroutine(boom());
                    StopCoroutine(other.GetComponent<PlayerMove>().playerboom());
                }
            }
            else if (countdown == true)
            {
                if (cantrigger)
                {
                    cantrigger = false;
                    StartCoroutine(triggercd());
                    Debug.Log("Player is it");
                    countdown = false;
                    other.GetComponent<PlayerMove>().countd = true;
                    count.SetActive(false);
                    StopCoroutine(boom());
                    other.GetComponent<PlayerMove>().boomtimerp = 5;
                    other.GetComponent<PlayerMove>().countp.SetActive(true);
                    StartCoroutine(other.GetComponent<PlayerMove>().playerboom());
                    boomtimer = 5;
                }

            }
        }
    }


    //cooldown method
    public IEnumerator triggercd()
    {
        yield return new WaitForSeconds(1f);
        cantrigger = true;
    }
    //timer method
    public IEnumerator boom()
    {
        yield return new WaitForSeconds(1f);
        if (countdown)
        {
            Debug.Log("boom");

            boomtimer--;
            ////timer work
            if (boomtimer <= 0)
            {
                score();
                boomtimer = 5;
                StartCoroutine(boom());
            }
            else
            {
                StartCoroutine(boom());
            }
        }

    }

    //scoring method
    public void score()
    {
        //method scores a point
        Debug.Log("enemy score");
        escore++;
        txt.GetComponent<UnityEngine.UI.Text>().text = "Player 1 Score: " + escore;
    }








    //////////////movement
   public void OnSwapR()
        {
        Debug.Log("rswap");
        if (whichenemy == 1)
        {
            if (letterenemy == 2) whichenemy = 3;
            else
                whichenemy = 2;
        }
        else if (whichenemy == 2)
        {
            if (letterenemy == 3) whichenemy = 1;
            else
                whichenemy = 3;
        }
        else if (whichenemy == 3)
        {
            if (letterenemy == 1) whichenemy = 2;
            else whichenemy = 1;
        }
    }


    public void OnTest()
    {
        Debug.Log("Lswap");
        if (letterenemy == 1)
        {
            if (whichenemy == 2) letterenemy= 3;
            else
                letterenemy = 2;
        }
        else if (letterenemy == 2)
        {
            if (whichenemy == 3) letterenemy = 1;
            else
                letterenemy = 3;
        }
        else if (letterenemy == 3)
        {
            if (whichenemy == 1) letterenemy = 2;
            else
                letterenemy = 1;
        }
    }
    public void jumpLeft()
    {
        jumpL = true;
    }

    public void jumpR()
    {
        jump = true;
    }
    public void testmethod()
    {
        Debug.Log("rswap");
        if (whichenemy == 1)
        {
            if (letterenemy == 2) whichenemy = 3;
            else
                whichenemy = 2;
        }
        else if (whichenemy == 2)
        {
            if (letterenemy == 3) whichenemy = 1;
            else
                whichenemy = 3;
        }
        else if (whichenemy == 3)
        {
            if (letterenemy == 1) whichenemy = 2;
            else whichenemy = 1;
        }
    }
}
